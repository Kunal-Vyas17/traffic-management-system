  # image_path = r"C:/Users/samar/OneDrive/Desktop/CODING/Python/Mynewproj/Smart-Traffic-Management/images/right/truck.png"
        # self.currentImage = pygame.image.load(image_path)
        # image_path = r"C:/Users/samar/OneDrive/Desktop/CODING/Python/Mynewproj/Smart-Traffic-Management/images/right/car.png"
        # self.currentImage = pygame.image.load(image_path)
        # image_path = r"C:/Users/samar/OneDrive/Desktop/CODING/Python/Mynewproj/Smart-Traffic-Management/images/right/rickshaw.png"
        # self.currentImage = pygame.image.load(image_path)
        # image_path = r"C:/Users/samar/OneDrive/Desktop/CODING/Python/Mynewproj/Smart-Traffic-Management/images/right/bus.png"
        # self.currentImage = pygame.image.load(image_path)
        